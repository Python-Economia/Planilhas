'''
Blanchard, 7 ed.
Capítulo 3: O mercado de bens
Extensão 2, Contração fiscal
Economia Fechada
Variáveis Endógenas: Consumo (C)
Variáveis Exógenas: G, I, T
'''

'''
Estrutura Economica (Extensão 1 do modelo básico, inclusão de Bt)
Y: produto
Z = C + I + G
C = c0 + c1*(Y-T)
I = Ibarra
G = Gbarra
T = Tbarra
Y = Z [Equilibrio de mercado]
S = Y - T - C  [Poupança Privada]
Sg = T - G   [Poupança Pública]
Bt = Bt-1 + G - T  Extensão 1 do modelo básico [Evolução do estoque da dívida pública B, considerando r = 0 por simplificação]
'''

from pylab import plot, subplot, title, subplots_adjust

# Parâmetros
c0 = 100.0
c1 = 0.6
Ibarra = 30.0
Gbarra = 50.0
Tbarra = 50.0
Kbarra = 140625.0
alpha = 0.5
B = 0.00 # Extensão 1 do modelo básico (no tempo -1, considera-se que o governo não tinha dívida)    

# Choques em t = 5
choque_c0 = + 0.0
choque_investimento = + 0.0
choque_governo = - 5.0
choque_imposto = + 0.0

# Resolução

Produto=[]
Consumo=[]
Investimento=[]
Governo=[]
Imposto=[]
Poupança_Privada=[]
Poupança_Publica=[]
Divida_Publica=[] # Extensão 1 do modelo básico
Trabalho=[] #Extensão 2
Tempo=range(11)

for T in Tempo[0:11]:
    if T==5:
        c0=c0+choque_c0
        Ibarra=Ibarra+choque_investimento
        Gbarra=Gbarra+choque_governo
        Tbarra=Tbarra+choque_imposto
    Y=(1/(1-c1))*(c0+Ibarra+Gbarra-c1*Tbarra)
    C=c0+c1*(Y-Tbarra)
    S=Y-Tbarra-C
    Sg=Tbarra-Gbarra
    B=B+Gbarra-Tbarra # Extensão 1 do modelo básico
    L=(Y**(1/(1-alpha)))/(Kbarra**(alpha/(1-alpha))) #Extensão 2
    Produto.append(Y)
    Consumo.append(C)
    Investimento.append(Ibarra)
    Governo.append(Gbarra)
    Imposto.append(Tbarra)
    Poupança_Privada.append(S)
    Poupança_Publica.append(Sg)
    Divida_Publica.append(B) # Extensão 1 do modelo básico
    Trabalho.append(L) #Extensão 2
    
        
# Graficos
subplots_adjust(bottom=0.1, top=3.0,wspace=0.2,hspace=1.0)    

subplot(10,1,1)
plot(Tempo,Produto)
title('Produto')

subplot(10,1,2)
plot(Tempo,Consumo)
title('Consumo')

subplot(10,1,3)
plot(Tempo,Investimento)
title('Investimento')

subplot(10,1,4)
plot(Tempo,Governo)
title('Gastos do Governo')

subplot(10,1,5)
plot(Tempo,Imposto)
title('Imposto')

subplot(10,1,6)
plot(Tempo, Investimento)
title('Investimento')

subplot(10,1,7)
plot(Tempo,Poupança_Privada)
title('Poupança Privada')

subplot(10,1,8)
plot(Tempo,Poupança_Publica)
title('Poupança Pública')

subplot(10,1,9) # Extensão 1 do modelo básico
plot(Tempo,Divida_Publica)
title('Estoque da Dívida Pública')

subplot(10,1,10) #subplot(# Extensão 2
plot(Tempo,Trabalho)
title('Trabalho')

print('Produto: {Produto}')
print('Consumo: {Consumo}')
print('Investimento: {Investimento}')
print('Governo: {Governo}')
print('Imposto: {Imposto}')
print('EStoque da Dívida Pública: {Divida_Publica}') # Extensão 1 do modelo básico
print('Trabalho: {Trabalho}') 