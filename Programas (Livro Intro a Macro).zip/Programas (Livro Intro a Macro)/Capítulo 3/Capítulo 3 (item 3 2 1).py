'''
Blanchard, 7 ed.
Capítulo 3: O mercado de bens
Economia Fechada
Variáveis Endógenas: Consumo (C)
Variáveis Exógenas: G, I, T
'''

'''
Estrutura Economica
Y: produto
Z = C + I + G
C = c0 + c1*(Y-T)
I = Ibarra
G = Gbarra
T = Tbarra
Y = Z [Equilibrio de mercado]
S = Y - T - C  [Poupança Privada]
Sg = T - G   [Poupança Pública]
'''

from pylab import plot, subplot, title, subplots_adjust

# Parâmetros
c0 = 100.0
c1 = 0.6
Ibarra = 30.0
Gbarra = 50.0
Tbarra = 50.0

# Choques em t = 5
choque_c0 = + 1.0
choque_investimento = + 0.0
choque_governo = + 0.0
choque_imposto = + 0.0

# Resolução

Produto=[]
Consumo=[]
Investimento=[]
Governo=[]
Imposto=[]
Poupança_Privada=[]
Poupança_Publica=[]
Tempo=range(11) # Tempo de 0 a 10

for T in Tempo[0:11]:
    if T==5:
        c0=c0+choque_c0
        Ibarra=Ibarra+choque_investimento
        Gbarra=Gbarra+choque_governo
        Tbarra=Tbarra+choque_imposto
    Y=(1/(1-c1))*(c0+Ibarra+Gbarra-c1*Tbarra)
    C=c0+c1*(Y-Tbarra)
    S=Y-Tbarra-C
    Sg=Tbarra-Gbarra
    Produto.append(Y)
    Consumo.append(C)
    Investimento.append(Ibarra)
    Governo.append(Gbarra)
    Imposto.append(Tbarra)
    Poupança_Privada.append(S)
    Poupança_Publica.append(Sg)
           
# Graficos
subplots_adjust(bottom=0.1, top=3.0,wspace=0.2,hspace=1.0)    

subplot(811)
plot(Tempo,Produto)
title('Produto')

subplot(812)
plot(Tempo,Consumo)
title('Consumo')

subplot(813)
plot(Tempo,Investimento)
title('Investimento')

subplot(814)
plot(Tempo,Governo)
title('Gastos do Governo')

subplot(815)
plot(Tempo,Imposto)
title('Imposto')

subplot(816)
plot(Tempo, Investimento)
title('Investimento')

subplot(817)
plot(Tempo,Poupança_Privada)
title('Poupança Privada')

subplot(818)
plot(Tempo,Poupança_Publica)
title('Poupança Pública')

print(f'Produto: {Produto}')
print(f'Consumo: {Consumo}')
print(f'Investimento: {Investimento}')
print(f'Governo: {Governo}')
print(f'Imposto: {Imposto}')
print(f'Poupança Privada: {Poupança_Privada}')
print(f'Poupança Pública: {Poupança_Publica}')

