'''
Blanchard, 7 ed.
Capítulo 4 e 5: O modelo IS-LM
Economia Fechada
Variáveis Endógenas: Consumo (C), Investimento (I)
Variáveis Exógenas: G, T
'''

'''
Estrutura Economica
Mercado de Bens
Y: produto
Z = C + I + G
C = c0 + c1*(Y-T)
I = I0 - sigma1*i + sigma2*Y [Investimento Privado] 
G = Gbarra
T = Tbarra
Y = Z [Equilíbrio do mercado de bens: Relação IS]
S = Y - T - C  [Poupança Privada]
Sg = T - G   [Poupança Pública]

Mercado Monetário
Ms: Oferta Nominal de Moeda ; ms: Oferta real de moeda = Ms/P
MD/P = σ_3*Y - σ_4*i	[Demanda Real por moeda]
Ms/P = Mbarra	[Oferta Real de Moeda determinada pelo Banco Central]
Ms/P = σ_3*Y - σ_4*i	[Equilíbrio do mercado monetário (Relação LM)]

'''

from pylab import plot, subplot, title, subplots_adjust

# Parâmetros e variáveis exógenas
c0 = 100.0	# Consumo Autônomo
c1 = 0.6	# Propensão Marginal a consumir
I0 = 17.5	# Investimento Autônomo
sigma1 = 5.0	# Sensibilidade do Investimento Privado em relação à taxa de juros i
sigma2 = 0.1    # Sensibilidade do Investimento em relação ao produto real Y [Restrição: c1 + sigma2 < 1] 
sigma3 = 1.0	# Sensibilidade da demanda real por moeda em relação ao produto real Y
sigma4 = 10	# Sensibilidade da demanda real por moeda em relação à taxa de juros i
P = 1.0		# Nível de preços
Gbarra = 50.0	# Gastos do governo
Tbarra = 50.0	# Tributos (Total de arrecadação líquido de transferências)
i = 5.0		# em %. Taxa de juros fixada pelo BC como instrumendo da Política Monetária 

# Choques em t = 5
choque_c0 = + 0.0
choque_I0 = + 0.0
choque_governo = + 0.0
choque_imposto = + 0.0
choque_juros = - 1.0

# Resolução

Produto=[]
Consumo=[]
Investimento=[]
Governo=[]
Imposto=[]
Poupança_Privada=[]
Poupança_Publica=[]
Taxa_Juros=[]
Oferta_Nominal_Moeda=[]
Oferta_Real_Moeda=[]
Tempo=range(11) # Tempo de 0 a 10

for T in Tempo[0:11]:
    if T==5:
        c0=c0+choque_c0
        I0=I0+choque_I0
        Gbarra=Gbarra+choque_governo
        Tbarra=Tbarra+choque_imposto
        i=i+choque_juros
    Y=(1/(1-c1-sigma2))*(c0+I0+Gbarra-c1*Tbarra-sigma1*i)
    C=c0+c1*(Y-Tbarra)
    I=I0-sigma1*i+sigma2*Y
    S=Y-Tbarra-C
    Sg=Tbarra-Gbarra
    Ms=(sigma3*Y-sigma4*i)*P   # Oferta Nominal de Moeda 
    ms=Ms/P     # Oferta Real de Moeda
    Produto.append(Y)
    Consumo.append(C)
    Investimento.append(I)
    Governo.append(Gbarra)
    Imposto.append(Tbarra)
    Poupança_Privada.append(S)
    Poupança_Publica.append(Sg)
    Taxa_Juros.append(i)
    Oferta_Nominal_Moeda.append(Ms)
    Oferta_Real_Moeda.append(ms)
         
# Graficos
subplots_adjust(bottom=0.1, top=3.0,wspace=0.2,hspace=1.0)    

subplot(11,1,1)
plot(Tempo,Produto)
title('Produto')

subplot(11,1,2)
plot(Tempo,Consumo)
title('Consumo')

subplot(11,1,3)
plot(Tempo,Investimento)
title('Investimento')

subplot(11,1,4)
plot(Tempo,Governo)
title('Gastos do Governo')

subplot(11,1,5)
plot(Tempo,Imposto)
title('Imposto')

subplot(11,1,6)
plot(Tempo, Investimento)
title('Investimento')

subplot(11,1,7)
plot(Tempo,Poupança_Privada)
title('Poupança Privada')

subplot(11,1,8)
plot(Tempo,Poupança_Publica)
title('Poupança Pública')

subplot(11,1,9)
plot(Tempo,Taxa_Juros)
title('Taxa de Juros (%)')

subplot(11,1,10)
plot(Tempo, Oferta_Nominal_Moeda)
title('Oferta Nominal de Moeda')

subplot(11,1,11)
plot(Tempo, Oferta_Real_Moeda)
title('Oferta Real de Moeda')

print(f'Produto: {Produto}')
print(f'Consumo: {Consumo}')
print(f'Investimento: {Investimento}')
print(f'Governo: {Governo}')
print(f'Imposto: {Imposto}')
print(f'Poupança Privada: {Poupança_Privada}')
print(f'Poupança Pública: {Poupança_Publica}')
print(f'Taxa de Juros em p.p.: {Taxa_Juros}')
print(f'Oferta Nominal de Moeda: {Oferta_Nominal_Moeda}')
print(f'Oferta Real de Moeda: {Oferta_Real_Moeda}')