'''
Blanchard, 7 ed.
Capítulo 6: O modelo IS-LM
Economia Fechada
'''

'''
Estrutura Economica
Mercado de Bens
Y: produto
Z = C + I + G
C = c0 + c1*(Y-T)
I = sigma0 - sigma5*(i - expectativa_inflacao + premio_risco) + sigma2*Y [Investimento Privado] 
G = Gbarra
T = Tbarra
Y = Z [Equilíbrio do mercado de bens: Relação IS]
S = Y - T - C  [Poupança Privada]
Sg = T - G   [Poupança Pública]

Mercado Monetário
Ms: Oferta Nominal de Moeda ; ms: Oferta real de moeda = Ms/P
Md/P = σ_3*Y - σ_4*i	[Demanda Real por moeda]
Ms/P = Mbarra	[Oferta Real de Moeda]
Ms/P = σ_3*Y - σ_4*i	[Equilíbrio do mercado monetário (Relação LM)]
ibarra: taxa de juros de política determinada pelo Banco Central

Mercado Financeiro
premio_risco	[taxa de juros acima da taxa nominal de política do BC]
expectativa_inflacao	[expectativa de inflação de mercado]

'''

from pylab import plot, subplot, title, subplots_adjust

# Parâmetros e variáveis exógenas
c0 = 100.0	# Consumo Autônomo
c1 = 0.6	# Propensão Marginal a consumir
sigma0 = 17.5	# Investimento Autônomo
sigma2 = 0.1    # Sensibilidade do Investimento em relação ao produto real Y [Restrição: c1 + sigma2 < 1] 
sigma3 = 1.0	# Sensibilidade da demanda real por moeda em relação ao produto real Y
sigma4 = 10	# Sensibilidade da demanda real por moeda em relação à taxa de juros i
sigma5 = 5.0	# Sensibilidade do Investimento Privado em relação à taxa real de juros de mercado 
P = 1.0		# Nível de preços
Gbarra = 50.0	# Gastos do governo
Tbarra = 50.0	# Tributos (Total de arrecadação líquido de transferências)
ibarra = 5.0	# em %. Taxa nominal de juros fixada pelo BC como instrumendo da Política Monetária 
expectativa_inflacao = 3.5  # Inflação esperada em %
premio_risco = 1.0          # Prêmio de risco cobrado nas operações de empréstimo do setor privado (%)

# Choques em t = 5
choque_c0 = + 0.0
choque_sigma0 = + 0.0
choque_governo = + 0.0
choque_imposto = + 0.0
choque_ibarra = + 0.0
choque_expectativa_inflacao = + 0.0
choque_premio_risco = + 0.0

# Resolução

Produto = []
Consumo = []
Investimento = []
Governo = []
Imposto = []
Poupança_Privada = []
Poupança_Publica = []
Expectativa_Inflacao = []	# capítulo 3
Premio_Risco = []	# capítulo 3
Taxa_Nominal_BC = []	# capítulo 3
Taxa_Real_BC = []	# capítulo 3
Taxa_Real_Mercado = []	# capítulo 3
Oferta_Nominal_Moeda = []
Oferta_Real_Moeda = []
Tempo=range(11) # Tempo de 0 a 10

for T in Tempo[0:11]:
    if T==5:
        c0 = c0 + choque_c0
        sigma0 = sigma0 + choque_sigma0
        Gbarra = Gbarra + choque_governo
        Tbarra = Tbarra + choque_imposto
        ibarra = ibarra + choque_ibarra
        expectativa_inflacao = expectativa_inflacao + choque_expectativa_inflacao	# capítulo 3
        premio_risco = premio_risco + choque_premio_risco
    Y = (1 / (1 - c1 - sigma2))*(c0 + sigma0 + Gbarra - c1*Tbarra - sigma5*(ibarra - expectativa_inflacao + premio_risco))	# capítulo 3
    C = c0 + c1*(Y-Tbarra)
    I = sigma0 - sigma5*(ibarra - expectativa_inflacao + premio_risco) + sigma2*Y
    S = Y - Tbarra - C
    Sg = Tbarra - Gbarra
    Ms = (sigma3*Y-sigma4*ibarra)*P   # Oferta Nominal de Moeda
    ms = Ms/P     # Oferta Real de Moeda
    Produto.append(Y)
    Consumo.append(C)
    Investimento.append(I)
    Governo.append(Gbarra)
    Imposto.append(Tbarra)
    Poupança_Privada.append(S)
    Poupança_Publica.append(Sg)
    Expectativa_Inflacao.append(expectativa_inflacao)
    Premio_Risco.append(premio_risco)
    Taxa_Nominal_BC.append(ibarra)
    Taxa_Real_BC.append(ibarra - expectativa_inflacao)
    Taxa_Real_Mercado.append(ibarra - expectativa_inflacao + premio_risco)	
    Oferta_Nominal_Moeda.append(Ms)
    Oferta_Real_Moeda.append(ms)
    
        
# Graficos
subplots_adjust(bottom=0.1, top=3.0,wspace=0.2,hspace=1.0)    

subplot(15,1,1)
plot(Tempo,Produto)
title('Produto')

subplot(15,1,2)
plot(Tempo,Consumo)
title('Consumo')

subplot(15,1,3)
plot(Tempo,Investimento)
title('Investimento')

subplot(15,1,4)
plot(Tempo,Governo)
title('Gastos do Governo')

subplot(15,1,5)
plot(Tempo,Imposto)
title('Imposto')

subplot(15,1,6)
plot(Tempo, Investimento)
title('Investimento')

subplot(15,1,7)
plot(Tempo,Poupança_Privada)
title('Poupança Privada')

subplot(15,1,8)
plot(Tempo,Poupança_Publica)
title('Poupança Pública')

subplot(15, 1, 9) # capítulo 3
plot(Tempo, Expectativa_Inflacao)
title('Expectativa de Inflação (%)')

subplot(15, 1, 10) # capítulo 3
plot(Tempo, Premio_Risco)
title('Prêmio de Risco (%)')

subplot(15,1,11)	# capítulo 3
plot(Tempo,Taxa_Nominal_BC)
title('Taxa Nominal de Juros do BC (%)')

subplot(15, 1, 12)	# capítulo 3
plot(Tempo, Taxa_Real_BC)
title('Taxa Real de Juros do BC (%)')

subplot(15, 1, 13)	# capítulo 3
plot(Tempo, Taxa_Real_Mercado)
title('Taxa Real de Juros de Mercado (%)')

subplot(15, 1, 14)
plot(Tempo, Oferta_Nominal_Moeda)
title('Oferta Nominal de Moeda')

subplot(15, 1, 15)
plot(Tempo, Oferta_Real_Moeda)
title('Oferta Real de Moeda')

print(f'Produto: {Produto}')
print(f'Consumo: {Consumo}')
print(f'Investimento: {Investimento}')
print(f'Governo: {Governo}')
print(f'Imposto: {Imposto}')
print(f'Poupança Privada: {Poupança_Privada}')
print(f'Poupança Pública: {Poupança_Publica}')
print(f'Expectativa de Inflação em p.p.: {Expectativa_Inflacao}')
print(f'Prêmio de Risco em p.p.: {Premio_Risco}')
print(f'Taxa Nominal de Juros do BC em p.p.: {Taxa_Nominal_BC}')
print(f'Taxa Real de Juros do BC em p.p.: {Taxa_Real_BC}')
print(f'Taxa Real de Juros de Mercado em p.p.: {Taxa_Real_Mercado}')
print(f'Oferta Nominal de Moeda: {Oferta_Nominal_Moeda}')
print(f'Oferta Real de Moeda: {Oferta_Real_Moeda}')
